import 'package:flutter/material.dart';
import 'package:pensol/app/modules/menus/claimGift/providers/claim_gift_provider.dart';
import 'package:pensol/app/modules/menus/couponHistory/providers/coupon_history_provider.dart';
import 'package:pensol/app/modules/menus/notification/providers/notification_provider.dart';
import 'package:pensol/app/modules/splash/splash_page.dart';
import './app/modules/auth/login/providers/login_provider.dart';
import 'package:provider/provider.dart';
import './app/modules/home/providers/home_provider.dart';
import './app/routes/route_generator.dart';
import './app/routes/route_names.dart';
import './app/themes/dark_theme.dart';
import './app/themes/light_theme.dart';
import './core/api/injector.dart';


final GlobalKey<NavigatorState> navigatorKey = GlobalKey();

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  setUpInjection();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => LoginProvider()),
        ChangeNotifierProvider(create: (_) => HomeProvider()),
        ChangeNotifierProvider(create: (_) => ClaimGiftProvider()),
        ChangeNotifierProvider(create: (_) => CouponHistoryProvider()),
        ChangeNotifierProvider(create: (_) => NotificationProvider()),
      ],
      child: MaterialApp(
        title: 'Flutter Demo',
        theme: lightTheme,
        darkTheme: darkTheme,
        navigatorKey: navigatorKey,
        initialRoute: getIntialPage(),
        onGenerateRoute: RouteGenerator.generateRoute,
        home: const SplashPage(),

        
      ),
    );
  }
  String getIntialPage() => AppRoutes.onBoarding;
}

