import 'package:flutter/material.dart';

class AppElevatedButton extends StatelessWidget {
  const AppElevatedButton(
    this.title, {
    Key? key,
    this.onTap,
    this.width = double.infinity,
    this.height = 50,
  }) : super(key: key);

  /// string button title
  final String title;

  /// function button pressed
  final Function()? onTap;

  /// double button width
  final double width;

  /// double button height
  final double height;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: height,
      child: ElevatedButton(
        child: Text(title),
        onPressed: onTap,
      ),
    );
  }
}
