import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../app/constants/app_spacing.dart';

class AppTextField extends StatelessWidget {
  /// constructor
  const AppTextField({
    Key? key,
    this.prefixIcon,
    this.controller,
    this.hintText,
    this.obscureText = false,
    this.inputFormatter,
    this.validator,
    this.onChanged,
    this.textInputAction,
    this.keyboardType,
  }) : super(key: key);

  /// prefix IconData
  final IconData? prefixIcon;

  /// textfield controller
  final TextEditingController? controller;

  /// hint text String
  final String? hintText;

  /// bool obscure text
  final bool obscureText;

  /// text field formatter
  final List<TextInputFormatter>? inputFormatter;

  /// function for validation
  final String? Function(String?)? validator;

  /// function on change
  final Function(String)? onChanged;

  /// text input actions
  final TextInputAction? textInputAction;

  /// keyboard type
  final TextInputType? keyboardType;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      obscureText: obscureText,
      validator: validator,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        contentPadding: const EdgeInsets.all(AppSpacing.md),
        prefixIcon: Container(
          padding: const EdgeInsets.symmetric(vertical: AppSpacing.md),
          margin: const EdgeInsets.only(right: AppSpacing.sm),
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(30.0),
              bottomLeft: Radius.circular(30.0),
              topRight: Radius.circular(30.0),
              bottomRight: Radius.circular(10.0),
            ),
          ),
          child: Icon(
            prefixIcon,
            color: Theme.of(context).primaryColor,
          ),
        ),
        hintText: hintText,
        hintStyle: const TextStyle(color: Colors.white),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30.0),
          borderSide: BorderSide.none,
        ),
        filled: true,
        fillColor: Colors.white.withOpacity(0.1),
      ),
    );
  }
}
