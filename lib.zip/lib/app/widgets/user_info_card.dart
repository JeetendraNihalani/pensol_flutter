import 'package:flutter/material.dart';
import 'package:liquid_progress_indicator/liquid_progress_indicator.dart';
import 'package:pensol/app/modules/home/providers/home_provider.dart';
import 'package:provider/provider.dart';
import '../../app/constants/app_spacing.dart';
import '../../app/constants/app_string.dart';
import '../../app/widgets/app_spacer.dart';

class UserPointInfo extends StatelessWidget {
  const UserPointInfo({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context).textTheme;
    return SizedBox(
      width: double.infinity,
      height: 160,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(AppSpacing.md),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(AppString.availablePoints),
              AppSpacer.p4(),
              Consumer<HomeProvider>(
                builder: (context, user, child) {
                  final _user = user.userDetails.result?[0];
                  return Text(
                    _user?.vAvailablePoints.toString() ?? '',
                    style: theme.headline5?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  );
                },
              ),
              AppSpacer.p8(),
              Row(
                children: [
                  Expanded(
                    child: SizedBox(
                      height: 10,
                      child: Consumer<HomeProvider>(
                        builder: (context, user, child) {
                          final _user = user.userDetails.result?[0];
                          final _availablePoints = _user?.vAvailablePoints?.toDouble() ?? 0.0;
                          final _nearestGiftPoints = _user?.vNearestGiftPoint?.toDouble() ?? 0.0;
                          final _achievedPercentage =  _availablePoints /  _nearestGiftPoints;
                          return LiquidLinearProgressIndicator(
                            value: _achievedPercentage, // Defaults to 0.5.
                            valueColor: AlwaysStoppedAnimation(
                              Theme.of(context).primaryColor,
                            ),
                            backgroundColor:
                                Theme.of(context).primaryColor.withOpacity(0.3),
                            direction: Axis.horizontal,
                            center: const Text(''),
                            borderRadius: AppSpacing.md,
                          );
                        },
                      ),
                    ),
                  ),
                  AppSpacer.p8(),
                  const Icon(Icons.insert_chart)
                ],
              ),
              AppSpacer.p8(),
              Consumer<HomeProvider>(
                builder: (context, user, child) {
                  final _user = user.userDetails.result?[0];
                  return Text('${_user?.vNearestGiftPoint} Points to ${_user?.vNearestGiftName}',
                  style: theme.caption);
                },
              ),
              
            ],
          ),
        ),
      ),
    );
  }
}
