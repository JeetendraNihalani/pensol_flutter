import '../login_domain.dart';

abstract class LoginRepository {
  factory LoginRepository() => LoginService();

  Future login(
    String? mobileNumber,
    String? password,
    String? deviceMake,
    String? deviceName,
    String? deviceToken,
  );
}
