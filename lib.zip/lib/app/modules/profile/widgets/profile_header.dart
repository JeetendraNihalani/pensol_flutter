import 'package:flutter/material.dart';
import 'package:pensol/app/constants/app_spacing.dart';
import 'package:pensol/app/modules/home/providers/home_provider.dart';
import 'package:pensol/app/widgets/app_spacer.dart';
import 'package:provider/provider.dart';

class ProfileHeader extends StatelessWidget {
  const ProfileHeader({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(top: AppSpacing.xl),
      height: 240.0,
      child: Stack(
        children: <Widget>[
          Container(
            padding: const EdgeInsets.only(
              top: AppSpacing.xl,
              left: AppSpacing.xl,
              right: AppSpacing.xl,
              bottom: AppSpacing.md,
            ),
            child: Material(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0)),
              elevation: 5.0,
              color: Colors.white,
              child: Column(
                children: <Widget>[
                  AppSpacer.p48(),
                  AppSpacer.p8(),
                  Consumer<HomeProvider>(
                    builder: (context, user, child) {
                      final firstName =
                          user.userDetails.result?[0].vFirstName;
                      final lastName =
                          user.userDetails.result?[0].vFirstName;
                      return Text(
                        '$firstName $lastName',
                        style: Theme.of(context).textTheme.subtitle1,
                      );
                    },
                  ),
                  AppSpacer.p4(),
                  Consumer<HomeProvider>(
                    builder: (context, user, child) {
                      final shopName = user.userDetails.result?[0].shopName;

                      return Text(
                        '$shopName',
                        style: Theme.of(context).textTheme.caption,
                      );
                    },
                  ),
                  AppSpacer.p16(),
                  SizedBox(
                    height: 40.0,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Expanded(
                          child: Consumer<HomeProvider>(
                            builder: (context, user, child) {
                              final availablePoints = user
                                  .userDetails.result?[0].vAvailablePoints;

                              return ListTile(
                                title: Text(
                                  availablePoints.toString(),
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold),
                                ),
                                subtitle: Text(
                                    "Earned Points".toUpperCase(),
                                    textAlign: TextAlign.center,
                                    style: const TextStyle(fontSize: 12.0)),
                              );
                            },
                          ),
                        ),
                        Expanded(
                          child: Consumer<HomeProvider>(
                            builder: (context, user, child) {
                              final nearestGift = user
                                  .userDetails.result?[0].vNearestGiftName;

                              return ListTile(
                                title: Text(
                                  nearestGift.toString(),
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold),
                                ),
                                subtitle: Text("Next Gift".toUpperCase(),
                                    textAlign: TextAlign.center,
                                    style: const TextStyle(fontSize: 12.0)),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
          Align(
            alignment: Alignment.topCenter,
            child: Material(
              elevation: 5.0,
              shape: const CircleBorder(),
              child: Consumer<HomeProvider>(
                builder: (context, user, child) {
                  final userImage = user.userDetails.result?[0].profilePic;
                  return const CircleAvatar(
                    radius: 40.0,
                    backgroundImage:
                        NetworkImage('https://picsum.photos/200'),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
