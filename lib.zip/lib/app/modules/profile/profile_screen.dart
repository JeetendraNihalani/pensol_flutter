import 'package:flutter/material.dart';
import 'package:pensol/app/modules/profile/widgets/profile_header.dart';
import 'package:pensol/app/modules/profile/widgets/user_info.dart';
import 'package:pensol/app/widgets/app_bar_widget.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final containerColor = Theme.of(context).appBarTheme.backgroundColor;
    return Scaffold(
      appBar: const SimpleAppBar(title: 'Profile'),
      body: Stack(
        children: <Widget>[
          Container(
            height: 200.0,
            color: containerColor,
          ),
          ListView(
            children: const [ProfileHeader(), UserInfo()],
          )
        ],
      ),
    );
  }
}
