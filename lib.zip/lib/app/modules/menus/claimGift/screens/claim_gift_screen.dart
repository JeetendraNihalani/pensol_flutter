import 'package:flutter/material.dart';
import 'package:pensol/app/modules/menus/claimGift/providers/claim_gift_provider.dart';
import 'package:pensol/app/widgets/app_loading_widget.dart';
import 'package:pensol/core/api/api_constant.dart';
import 'package:provider/provider.dart';
import 'package:provider/src/provider.dart';
import '../../../../../../app/constants/app_spacing.dart';
import '../../../../../../app/modules/menus/claimGift/widgets/gift_card.dart';
import '../../../../../../app/widgets/app_bar_widget.dart';
import '../../../../../../app/widgets/app_spacer.dart';
import '../../../../../../app/widgets/user_info_card.dart';

class ClaimGiftScreen extends StatefulWidget {
  const ClaimGiftScreen({Key? key}) : super(key: key);

  @override
  State<ClaimGiftScreen> createState() => _ClaimGiftScreenState();
}

class _ClaimGiftScreenState extends State<ClaimGiftScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance?.addPostFrameCallback((timeStamp) {
      context.read<ClaimGiftProvider>().getClaimGifts();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const SimpleAppBar(
        title: '',
      ),
      body: Padding(
        padding: const EdgeInsets.all(AppSpacing.sm),
        child: Column(
          children: [
            const UserPointInfo(),
            AppSpacer.p16(),
            Expanded(
              child: Consumer<ClaimGiftProvider>(
                builder: (context, claimgiftList, child) {
                  final claimGiftList =
                      claimgiftList.claimgiftList.claimGiftListResult;
                  final claimGiftCount = claimGiftList?.length;

                  if (claimgiftList.appState == AppState.loading) {
                    return const AppLoadingWidget();
                  }
                  return ListView.builder(
                    itemCount: claimGiftCount,
                    itemBuilder: (context, index) {
                      final claimGift = claimGiftList?[index];
                      return GiftCard(
                        productName: claimGift?.giftName ?? '',
                        requirePoints:
                            claimGift?.redeemablePoints.toString() ?? '',
                        quantity: claimGift?.giftQty ?? 1,
                        onQtyChanged: () {},
                      );
                    },
                  );
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}
