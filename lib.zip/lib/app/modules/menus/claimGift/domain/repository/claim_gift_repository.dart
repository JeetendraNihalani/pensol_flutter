



import 'package:pensol/app/modules/menus/claimGift/domain/models/get_claim_gift_list_model.dart';

import '../claim_gift_domain.dart';

abstract class ClaimGiftRepository {

  factory ClaimGiftRepository() => ClaimGiftService();

  
  Future getClaimGiftList();
}