import 'package:flutter/material.dart';
import '../../../../../../app/constants/app_spacing.dart';
import '../../../../../../app/constants/app_string.dart';
import '../../../../../../app/widgets/app_elevated_button.dart';
import '../../../../../../app/widgets/app_quantity_widget.dart';
import '../../../../../../app/widgets/app_spacer.dart';

class GiftCard extends StatelessWidget {
  const GiftCard({
    Key? key,
    this.productImage,
    this.productName,
    this.requirePoints,
    this.onCLaim,
    this.onQtyChanged,
    this.quantity,
  }) : super(key: key);

  ///  string product image
  final String? productImage;

  ///  string product name
  final String? productName;

  ///  string required points
  final String? requirePoints;

  /// function on CLaim
  final Function()? onCLaim;

  /// function onQtyChanged
  final Function()? onQtyChanged;

  /// int quantity
  final int? quantity;
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context).textTheme;
    return SizedBox(
      width: double.infinity,
      height: 160,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(AppSpacing.md),
          child: Row(
            children: [
              // Image.asset(productImage ?? AppImages.scan),
              AppSpacer.p16(),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      productName ?? 'N.A',
                      style: theme.headline5
                          ?.copyWith(overflow: TextOverflow.ellipsis),
                    ),
                    AppSpacer.p16(),
                    Text(
                      'Required Points: ${requirePoints ?? 'N.A'}',
                      style: theme.subtitle1,
                    ),
                    
                    AppSpacer.p8(),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        AppQuantityWidget(
                          onQtyChanged: onQtyChanged,
                          qty: quantity,
                        ),
                        AppElevatedButton(
                          AppString.claim,
                          width: 100,
                          height: 40,
                          onTap: () {},
                        )
                      ],
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
