


import 'package:flutter/widgets.dart';
import '../../../../../../app/modules/menus/giftCollection/domain/gift_collection_domain.dart';

class GiftCollectionProvider extends ChangeNotifier {


    final repo = GiftCollectionRepository();



    doLogin()async{
      print('object');
      final string = await repo.login();
      print(string);
    }
}