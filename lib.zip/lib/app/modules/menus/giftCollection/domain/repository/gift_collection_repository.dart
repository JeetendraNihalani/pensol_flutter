



import '../gift_collection_domain.dart';

abstract class GiftCollectionRepository {

  factory GiftCollectionRepository() => GiftCollectionService();

  
  Future<String> login();
}