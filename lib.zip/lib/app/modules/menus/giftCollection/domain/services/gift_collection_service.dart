import '../../../../../../app/modules/menus/giftCollection/domain/gift_collection_domain.dart';
import '../../../../../../core/api/api_client.dart';
import '../../../../../../core/api/injector.dart';

class GiftCollectionService implements GiftCollectionRepository {

  ApiClient loginRepo = getIt.get<ApiClient>();

  @override
  Future<String> login() async {
    loginRepo.restApiCall();
    return Future.delayed(const Duration(seconds: 2), () {
      return 'object repo';
    });
  }
}
