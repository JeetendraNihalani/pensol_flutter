



import '../update_pin_domain.dart';

abstract class UpdatePinRepository {

  factory UpdatePinRepository() => UpdatePinService();

  
  Future<String> login();
}