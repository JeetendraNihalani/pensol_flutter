


import 'package:flutter/widgets.dart';
import '../../../../../../app/modules/menus/updatePin/domain/update_pin_domain.dart';

class UpdatePinProvider extends ChangeNotifier {


    final repo = UpdatePinRepository();



    doLogin()async{
      print('object');
      final string = await repo.login();
      print(string);
    }
}