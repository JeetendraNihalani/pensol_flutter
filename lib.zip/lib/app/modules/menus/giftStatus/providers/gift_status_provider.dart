


import 'package:flutter/widgets.dart';
import '../../../../../../app/modules/menus/giftStatus/domain/gift_status_domain.dart';

class GiftStatusProvider extends ChangeNotifier {


    final repo = GiftStatusRepository();



    doLogin()async{
      print('object');
      final string = await repo.login();
      print(string);
    }
}