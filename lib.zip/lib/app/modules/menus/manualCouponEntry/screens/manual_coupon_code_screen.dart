import 'package:flutter/material.dart';
import '../../../../../../app/widgets/app_bar_widget.dart';
import '../../../../../../app/widgets/app_empty_widget.dart';
import '../../../../../../app/widgets/app_spacer.dart';
import '../../../../../../app/widgets/user_info_card.dart';

class ManualCouponCodeScreen extends StatelessWidget {
  const ManualCouponCodeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const SimpleAppBar(
        title: '',
      ),
      body: Column(
      children: [
        const UserPointInfo(),
        AppSpacer.p16(),
        const AppNoData()
      ],
    ),
    );
  }
}
