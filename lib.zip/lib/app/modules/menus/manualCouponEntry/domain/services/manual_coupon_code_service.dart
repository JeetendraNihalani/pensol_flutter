import '../../../../../../app/modules/menus/manualCouponEntry/domain/manual_coupon_code_domain.dart';
import '../../../../../../core/api/api_client.dart';
import '../../../../../../core/api/injector.dart';

class ManualCouponCodeService implements ManualCouponCodeRepository {

  ApiClient loginRepo = getIt.get<ApiClient>();

  @override
  Future<String> login() async {
    loginRepo.restApiCall();
    return Future.delayed(const Duration(seconds: 2), () {
      return 'object repo';
    });
  }
}
