


import 'package:flutter/widgets.dart';
import '../../../../../../app/modules/menus/manualCouponEntry/domain/manual_coupon_code_domain.dart';

class ManualCouponCodeProvider extends ChangeNotifier {


    final repo = ManualCouponCodeRepository();



    doLogin()async{
      print('object');
      final string = await repo.login();
      print(string);
    }
}