



import '../coupon_history_domain.dart';

abstract class CouponHistoryRepository {

  factory CouponHistoryRepository() => CouponHistoryService();

  
  Future getCouponHistory();
}