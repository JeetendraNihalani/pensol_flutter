import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:pensol/app/modules/menus/couponHistory/providers/coupon_history_provider.dart';
import 'package:pensol/app/modules/menus/couponHistory/widgets/coupon_history_card.dart';
import 'package:pensol/app/widgets/app_loading_widget.dart';
import 'package:pensol/core/api/api_constant.dart';
import 'package:provider/provider.dart';
import 'package:provider/src/provider.dart';
import '../../../../../../app/widgets/app_bar_widget.dart';
import '../../../../../../app/widgets/app_spacer.dart';
import '../../../../../../app/widgets/user_info_card.dart';

class CouponHistoryScreen extends StatefulWidget {
  const CouponHistoryScreen({Key? key}) : super(key: key);

  @override
  State<CouponHistoryScreen> createState() => _CouponHistoryScreenState();
}

class _CouponHistoryScreenState extends State<CouponHistoryScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance?.addPostFrameCallback((timeStamp) {
      context.read<CouponHistoryProvider>().getCouponHistory();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const SimpleAppBar(
        title: '',
      ),
      body: Column(
        children: [
          const UserPointInfo(),
          AppSpacer.p16(),
          Expanded(
            child: Consumer<CouponHistoryProvider>(
              builder: (context, couponHistory, child) {
                if (couponHistory.appState == AppState.loading) {
                  return const AppLoadingWidget();
                }
                final _couponHistory = couponHistory.couponHistory;
                return ListView.builder(
                  itemCount: _couponHistory.couponHistoryResult?.length,
                  itemBuilder: (context, index) {
                    final couponHistory =
                        _couponHistory.couponHistoryResult?[index];
                    final parseDate = DateFormat("yyyy-MM-dd'T'HH:mm:ss")
                        .parse(couponHistory?.dModifiedOn ?? '');
                    final inputDate = DateTime.parse(parseDate.toString());
                    final outputFormat = DateFormat('dd-MMM-yyyy  HH:mm');
                    final couponDate = outputFormat.format(inputDate);
                    return CouponsHistoryCard(
                      leading: couponHistory?.productCode ?? '',
                      subtitle: couponDate,
                      title: '${couponHistory?.vSINo}',
                    );
                  },
                );
              },
            ),
          )
        ],
      ),
    );
  }
}
