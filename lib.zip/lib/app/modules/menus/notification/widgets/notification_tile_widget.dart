import 'dart:math';

import 'package:flutter/material.dart';

class NotificationTile extends StatelessWidget {
  const NotificationTile({
    Key? key,
    this.title,
    this.description,
    this.date,
    this.image,
  }) : super(key: key);

  /// string title of notification
  final String? title;

  /// string description of the notification
  final String? description;

  /// string date of notification
  final String? date;

  /// string image url of notification
  final String? image;
  @override
  Widget build(BuildContext context) {
    final _random = Random();
    return ListTile(
      tileColor: Colors.primaries[_random.nextInt(Colors.primaries.length)]
              [_random.nextInt(9) * 100]
          ?.withOpacity(0.2),
      leading: const Material(
        elevation: 5.0,
        shape: CircleBorder(),
        child: CircleAvatar(
          radius: 40.0,
          backgroundImage: NetworkImage('https://picsum.photos/200'),
        ),
      ),
      title: Text(title ?? 'Title'),
      subtitle: Text(description ?? ''),
      trailing: Text(date ?? ''),
      
    );
  }
}
