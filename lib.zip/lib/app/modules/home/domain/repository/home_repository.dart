




import '../../../../../../app/modules/home/domain/services/home_service.dart';

abstract class HomeRepository {

  factory HomeRepository() => HomeService();

  
  Future<String> login();
}