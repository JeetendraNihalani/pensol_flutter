


import 'package:flutter/widgets.dart';
import 'package:pensol/app/modules/auth/login/domain/models/auth_model.dart';
import 'package:pensol/core/services/auth_service.dart';
import '../../../../../../app/modules/home/domain/repository/home_repository.dart';

class HomeProvider extends ChangeNotifier {


    final repo = HomeRepository();

    /// user auth model
    AuthModel _userDetails = AuthModel();


    /// user details getter
    AuthModel get userDetails => _userDetails;


    /// get user details to show on home screen
    getUserDetails()async{
      _userDetails = await AuthService().userDetails();
      
      notifyListeners();
    }

    
}