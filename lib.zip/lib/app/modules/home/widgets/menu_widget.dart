import 'package:flutter/material.dart';
import '../../../../../../app/modules/home/widgets/menu_card.dart';


class Menus extends StatelessWidget {
  const Menus({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GridView(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
        ),
        children: [
          DashboardMenus.claimGift(),
          DashboardMenus.giftStatus(),
          DashboardMenus.couponHistory(),
          DashboardMenus.giftCollection(),
          DashboardMenus.enterCode(),
          DashboardMenus.updatePin(),
          DashboardMenus.notification(),
          DashboardMenus.logout()
        ],
      ),
    );
  }
}


