import 'package:flutter/material.dart';
import '../../../../../../app/constants/app_spacing.dart';
import '../../../../../../app/routes/route_names.dart';
import '../../../../../../app/widgets/app_spacer.dart';

import '../../../../main.dart';

class DashboardMenus extends StatelessWidget {
  const DashboardMenus._({
    Key? key,
    this.color,
    this.icon,
    required this.title,
    this.onTap,
  }) : super(key: key);

  /// background color of card
  final Color? color;

  /// icondata icon
  final IconData? icon;

  /// string title
  final String title;

  /// function ontap
  final Function()? onTap;

  factory DashboardMenus.claimGift() => DashboardMenus._(
        title: 'Claim Gift',
        color: Colors.pink,
        icon: Icons.explore_outlined,
        onTap: () => navigatorKey.currentState?.pushNamed(AppRoutes.claimGift),
      );

  factory DashboardMenus.giftStatus() => DashboardMenus._(
        title: 'Gift Status',
        color: Colors.purple,
        icon: Icons.fact_check_outlined,
        onTap: () => navigatorKey.currentState?.pushNamed(AppRoutes.giftStatus),
      );

  factory DashboardMenus.couponHistory() => DashboardMenus._(
        title: 'Coupons History',
        color: Colors.blue,
        icon: Icons.history_outlined,
        onTap: () => navigatorKey.currentState?.pushNamed(AppRoutes.couponHistory),
      );
  factory DashboardMenus.giftCollection() => DashboardMenus._(
        title: 'Gift Collection',
        color: Colors.indigo,
        icon: Icons.card_giftcard_outlined,
        onTap: () => navigatorKey.currentState?.pushNamed(AppRoutes.giftCollection),
      );
  factory DashboardMenus.enterCode() => DashboardMenus._(
        title: 'Enter Code',
        color: Colors.orange,
        icon: Icons.code_outlined,
        onTap: () => navigatorKey.currentState?.pushNamed(AppRoutes.manualCouponEntry),
      );

  factory DashboardMenus.updatePin() => DashboardMenus._(
        title: 'Update Pin',
        color: Colors.green,
        icon: Icons.pin_outlined,
        onTap: () => navigatorKey.currentState?.pushNamed(AppRoutes.updatePin),
      );

  factory DashboardMenus.notification() => DashboardMenus._(
        title: 'Notification',
        color: Colors.red,
        icon: Icons.notifications_outlined,
        onTap: () => navigatorKey.currentState?.pushNamed(AppRoutes.notification),
      );

  factory DashboardMenus.logout() => DashboardMenus._(
        title: 'Logout',
        color: Colors.yellow,
        icon: Icons.power_settings_new,
        onTap: () => navigatorKey.currentState?.pushReplacementNamed(AppRoutes.login),
      );

      

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(AppSpacing.sm),
        margin: const EdgeInsets.all(AppSpacing.sm),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(AppSpacing.md),
          color: color?.withOpacity(0.4),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              backgroundColor: color?.withOpacity(0.5),
              radius: AppSpacing.xl,
              child: RotationTransition(
                turns: const AlwaysStoppedAnimation(15 / 360),
                child: Icon(
                  icon,
                  size: AppSpacing.xl,
                ),
              ),
            ),
            AppSpacer.p16(),
            Text(title),
          ],
        ),
      ),
    );
  }

  
}