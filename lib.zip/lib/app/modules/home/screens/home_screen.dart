import 'package:flutter/material.dart';
import 'package:pensol/app/modules/home/providers/home_provider.dart';
import 'package:provider/src/provider.dart';
import '../../../../../../app/constants/app_spacing.dart';
import '../../../../../../app/constants/app_string.dart';
import '../../../../../../app/modules/home/widgets/menu_widget.dart';
import '../../../../../../app/widgets/app_bar_widget.dart';
import '../../../../../../app/widgets/app_spacer.dart';
import '../../../../../../app/widgets/app_text_avatar.dart';
import '../../../../../../app/widgets/user_info_card.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    context.read<HomeProvider>().getUserDetails();
    return Scaffold(
      appBar: SimpleAppBar(
        title: AppString.dashboard,
        actions: [
          Padding(
            padding: const EdgeInsets.all(AppSpacing.sm),
            child: TextAvatar(
              text: 'A D',
              numberLetters: 2,
            ),
          ),
          AppSpacer.p8(),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(AppSpacing.sm),
        child: Column(
          children: const [
            UserPointInfo(),
            Menus(),
          ],
        ),
      ),
    );
  }
}
