


class AppRoutes {
  static const onBoarding = 'onBoarding';
  static const splash = 'splash';
  static const login = 'login';
  static const home = 'home';
  static const profile = 'profile';

  static const claimGift = 'claimGift';
  static const couponHistory = 'couponHistory';
  static const giftCollection = 'giftCollection';
  static const giftStatus = 'giftStatus';
  static const manualCouponEntry = 'manualCouponEntry';
  static const notification = 'notification';
  static const updatePin = 'updatePin';
}