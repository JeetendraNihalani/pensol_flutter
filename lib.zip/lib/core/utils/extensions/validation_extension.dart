extension Validator on String {
  String? isPasswordValid() {

    if(length == 0){
      return 'Enter PIN Number';
    }

    if(length < 4){
      return 'PIN Number Must Contain 4 Numbers';
    }
    return null;
  }

  String? isMobileValid() {
    
    if(length == 10 && RegExp(r"^[6-9]\d{9}$").hasMatch(this)){
      return null;
    }

    if(length == 0){
      return 'Enter Mobile Number';
    }

    return 'Enter Valid Mobile Number';
  }
}
