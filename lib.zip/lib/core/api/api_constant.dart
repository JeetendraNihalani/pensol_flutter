

enum AppState {initial, loading, loaded, empty, error}

class ApiConstant {
  
  static const baseUrl = 'https://rds.webosphere.in/mobile.asmx/';

  /// login api constants
  static const login = 'login';

  /// claim gift list api constants
  static const claimGift = 'GetGiftList';

  /// coupon history api constants
  static const couponHistory = 'GetCouponHistory';

  /// get notification API constant
  static const getNotification = 'GetUsersNotification';

  
}